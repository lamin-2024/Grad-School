# ccopt saved state skew_groups.tcl.gz

## Tcl for skew_group
# Skew Group Mode: all
switch_ccopt_skew_group_mode -create all
# Skew Group: all
create_ccopt_skew_group -name all -generated  -auto_sinks -sources {{Dclk rise} {Sclk rise}}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: default
switch_ccopt_skew_group_mode -create default
# Skew Group: Dclk/my_constraint_mode
create_ccopt_skew_group -name Dclk/my_constraint_mode -from_clocks {Dclk} -from_constraint_modes {my_constraint_mode} -from_delay_corners {PVT_0P63V_100C.setup_delay PVT_0P77V_0C.hold_delay} -auto_sinks -sources {Dclk}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group: Sclk/my_constraint_mode
create_ccopt_skew_group -name Sclk/my_constraint_mode -from_clocks {Sclk} -from_constraint_modes {my_constraint_mode} -from_delay_corners {PVT_0P63V_100C.setup_delay PVT_0P77V_0C.hold_delay} -auto_sinks -sources {Sclk}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: fragment
switch_ccopt_skew_group_mode -create fragment
# Skew Group: 1
create_ccopt_skew_group -name 1 -generated  -fragment  -target_insertion_delay 77.7 -target_skew 20.1 -sinks {p2s/state_reg/CLK p2s/loaded_R_reg/CLK p2s/loaded_L_reg/CLK {p2s/data_R_reg[39]/CLK} {p2s/data_R_reg[38]/CLK} {p2s/data_R_reg[37]/CLK} {p2s/data_R_reg[36]/CLK} {p2s/data_R_reg[35]/CLK} {p2s/data_R_reg[34]/CLK} {p2s/data_R_reg[33]/CLK} {p2s/data_R_reg[32]/CLK} {p2s/data_R_reg[31]/CLK} {p2s/data_R_reg[30]/CLK} {p2s/data_R_reg[29]/CLK} {p2s/data_R_reg[28]/CLK} {p2s/data_R_reg[27]/CLK} {p2s/data_R_reg[26]/CLK} {p2s/data_R_reg[25]/CLK} {p2s/data_R_reg[24]/CLK} {p2s/data_R_reg[23]/CLK} {p2s/data_R_reg[22]/CLK} {p2s/data_R_reg[21]/CLK} {p2s/data_R_reg[20]/CLK} {p2s/data_R_reg[19]/CLK} {p2s/data_R_reg[18]/CLK} {p2s/data_R_reg[17]/CLK} {p2s/data_R_reg[16]/CLK} {p2s/data_R_reg[15]/CLK} {p2s/data_R_reg[14]/CLK} {p2s/data_R_reg[13]/CLK} {p2s/data_R_reg[12]/CLK} {p2s/data_R_reg[11]/CLK} {p2s/data_R_reg[10]/CLK} {p2s/data_R_reg[9]/CLK} {p2s/data_R_reg[8]/CLK} {p2s/data_R_reg[7]/CLK} {p2s/data_R_reg[6]/CLK} {p2s/data_R_reg[5]/CLK} {p2s/data_R_reg[4]/CLK} {p2s/data_R_reg[3]/CLK} {p2s/data_R_reg[2]/CLK} {p2s/data_R_reg[1]/CLK} {p2s/data_R_reg[0]/CLK} {p2s/data_L_reg[39]/CLK} {p2s/data_L_reg[38]/CLK} {p2s/data_L_reg[37]/CLK} {p2s/data_L_reg[36]/CLK} {p2s/data_L_reg[35]/CLK} {p2s/data_L_reg[34]/CLK} {p2s/data_L_reg[33]/CLK} {p2s/data_L_reg[32]/CLK} {p2s/data_L_reg[31]/CLK} {p2s/data_L_reg[30]/CLK} {p2s/data_L_reg[29]/CLK} {p2s/data_L_reg[28]/CLK} {p2s/data_L_reg[27]/CLK} {p2s/data_L_reg[26]/CLK} {p2s/data_L_reg[25]/CLK} {p2s/data_L_reg[24]/CLK} {p2s/data_L_reg[23]/CLK} {p2s/data_L_reg[22]/CLK} {p2s/data_L_reg[21]/CLK} {p2s/data_L_reg[20]/CLK} {p2s/data_L_reg[19]/CLK} {p2s/data_L_reg[18]/CLK} {p2s/data_L_reg[17]/CLK} {p2s/data_L_reg[16]/CLK} {p2s/data_L_reg[15]/CLK} {p2s/data_L_reg[14]/CLK} {p2s/data_L_reg[13]/CLK} {p2s/data_L_reg[12]/CLK} {p2s/data_L_reg[11]/CLK} {p2s/data_L_reg[10]/CLK} {p2s/data_L_reg[9]/CLK} {p2s/data_L_reg[8]/CLK} {p2s/data_L_reg[7]/CLK} {p2s/data_L_reg[6]/CLK} {p2s/data_L_reg[5]/CLK} {p2s/data_L_reg[4]/CLK} {p2s/data_L_reg[3]/CLK} {p2s/data_L_reg[2]/CLK} {p2s/data_L_reg[1]/CLK} {p2s/data_L_reg[0]/CLK} {p2s/cnt_reg[5]/CLK} {p2s/cnt_reg[4]/CLK} {p2s/cnt_reg[3]/CLK} {p2s/cnt_reg[2]/CLK} {p2s/cnt_reg[1]/CLK} {p2s/cnt_reg[0]/CLK} {main_control/zero_cnt_reg[9]/CLK} {main_control/zero_cnt_reg[8]/CLK} {main_control/zero_cnt_reg[7]/CLK} {main_control/zero_cnt_reg[6]/CLK} {main_control/zero_cnt_reg[5]/CLK} {main_control/zero_cnt_reg[4]/CLK} {main_control/zero_cnt_reg[3]/CLK} {main_control/zero_cnt_reg[2]/CLK} {main_control/zero_cnt_reg[1]/CLK} {main_control/zero_cnt_reg[0]/CLK} {main_control/state_reg[3]/CLK} {main_control/state_reg[2]/CLK} {main_control/state_reg[1]/CLK} {main_control/state_reg[0]/CLK} {main_control/addr_iter_reg[9]/CLK} {main_control/addr_iter_reg[8]/CLK} {main_control/addr_iter_reg[7]/CLK} {main_control/addr_iter_reg[6]/CLK} {main_control/addr_iter_reg[5]/CLK} {main_control/addr_iter_reg[4]/CLK} {main_control/addr_iter_reg[3]/CLK} {main_control/addr_iter_reg[2]/CLK} {main_control/addr_iter_reg[1]/CLK} {main_control/addr_iter_reg[0]/CLK} main_control/in_data_ready_d0_reg/CLK in_data_ready_sync_u/sync_med_reg/CLK in_data_ready_sync_u/sync_out_reg/CLK R_mem_R/mem_0_0/CE1 R_mem_L/mem_0_0/CE1 Frame_sync_u/sync_med_reg/CLK Frame_sync_u/sync_out_reg/CLK Data_mem_R/mem_0_1/CE Data_mem_R/mem_0_0/CE Data_mem_L/mem_0_1/CE Data_mem_L/mem_0_0/CE {Co_mem_R/cs_vec_reg[1]/CLK} {Co_mem_R/cs_vec_reg[0]/CLK} Co_mem_R/mem_0_3/CE Co_mem_R/mem_0_2/CE Co_mem_R/mem_0_1/CE Co_mem_R/mem_0_0/CE {Co_mem_L/cs_vec_reg[1]/CLK} {Co_mem_L/cs_vec_reg[0]/CLK} Co_mem_L/mem_0_3/CE Co_mem_L/mem_0_2/CE Co_mem_L/mem_0_1/CE Co_mem_L/mem_0_0/CE {ALU_R/y_reg[39]/CLK} {ALU_R/y_reg[38]/CLK} {ALU_R/y_reg[37]/CLK} {ALU_R/y_reg[36]/CLK} {ALU_R/y_reg[35]/CLK} {ALU_R/y_reg[34]/CLK} {ALU_R/y_reg[33]/CLK} {ALU_R/y_reg[32]/CLK} {ALU_R/y_reg[31]/CLK} {ALU_R/y_reg[30]/CLK} {ALU_R/y_reg[29]/CLK} {ALU_R/y_reg[28]/CLK} {ALU_R/y_reg[27]/CLK} {ALU_R/y_reg[26]/CLK} {ALU_R/y_reg[25]/CLK} {ALU_R/y_reg[24]/CLK} {ALU_R/y_reg[23]/CLK} {ALU_R/y_reg[22]/CLK} {ALU_R/y_reg[21]/CLK} {ALU_R/y_reg[20]/CLK} {ALU_R/y_reg[19]/CLK} {ALU_R/y_reg[18]/CLK} {ALU_R/y_reg[17]/CLK} {ALU_R/y_reg[16]/CLK} {ALU_R/y_reg[15]/CLK} {ALU_R/y_reg[14]/CLK} {ALU_R/y_reg[13]/CLK} {ALU_R/y_reg[12]/CLK} {ALU_R/y_reg[11]/CLK} {ALU_R/y_reg[10]/CLK} {ALU_R/y_reg[9]/CLK} {ALU_R/y_reg[8]/CLK} {ALU_R/y_reg[7]/CLK} {ALU_R/y_reg[6]/CLK} {ALU_R/y_reg[5]/CLK} {ALU_R/y_reg[4]/CLK} {ALU_R/y_reg[3]/CLK} {ALU_R/y_reg[2]/CLK} {ALU_R/y_reg[1]/CLK} {ALU_R/y_reg[0]/CLK} {ALU_R/state_reg[1]/CLK} {ALU_R/state_reg[0]/CLK} ALU_R/sign_delay_reg/CLK {ALU_R/j_reg[4]/CLK} {ALU_R/j_reg[3]/CLK} {ALU_R/j_reg[2]/CLK} {ALU_R/j_reg[1]/CLK} {ALU_R/j_reg[0]/CLK} {ALU_R/ite_reg[9]/CLK} {ALU_R/ite_reg[8]/CLK} {ALU_R/ite_reg[7]/CLK} {ALU_R/ite_reg[6]/CLK} {ALU_R/ite_reg[5]/CLK} {ALU_R/ite_reg[4]/CLK} {ALU_R/ite_reg[3]/CLK} {ALU_R/ite_reg[2]/CLK} {ALU_R/ite_reg[1]/CLK} {ALU_R/ite_reg[0]/CLK} {ALU_R/ite_delay_reg[3][8]/CLK} {ALU_R/ite_delay_reg[3][7]/CLK} {ALU_R/ite_delay_reg[3][6]/CLK} {ALU_R/ite_delay_reg[3][5]/CLK} {ALU_R/ite_delay_reg[3][4]/CLK} {ALU_R/ite_delay_reg[3][3]/CLK} {ALU_R/ite_delay_reg[3][2]/CLK} {ALU_R/ite_delay_reg[3][1]/CLK} {ALU_R/ite_delay_reg[3][0]/CLK} {ALU_R/ite_delay_reg[2][8]/CLK} {ALU_R/ite_delay_reg[2][7]/CLK} {ALU_R/ite_delay_reg[2][6]/CLK} {ALU_R/ite_delay_reg[2][5]/CLK} {ALU_R/ite_delay_reg[2][4]/CLK} {ALU_R/ite_delay_reg[2][3]/CLK} {ALU_R/ite_delay_reg[2][2]/CLK} {ALU_R/ite_delay_reg[2][1]/CLK} {ALU_R/ite_delay_reg[2][0]/CLK} {ALU_R/ite_delay_reg[1][8]/CLK} {ALU_R/ite_delay_reg[1][7]/CLK} {ALU_R/ite_delay_reg[1][6]/CLK} {ALU_R/ite_delay_reg[1][5]/CLK} {ALU_R/ite_delay_reg[1][4]/CLK} {ALU_R/ite_delay_reg[1][3]/CLK} {ALU_R/ite_delay_reg[1][2]/CLK} {ALU_R/ite_delay_reg[1][1]/CLK} {ALU_R/ite_delay_reg[1][0]/CLK} {ALU_R/R_accu_reg[8]/CLK} {ALU_R/R_accu_reg[7]/CLK} {ALU_R/R_accu_reg[6]/CLK} {ALU_R/R_accu_reg[5]/CLK} {ALU_R/R_accu_reg[4]/CLK} {ALU_R/R_accu_reg[3]/CLK} {ALU_R/R_accu_reg[2]/CLK} {ALU_R/R_accu_reg[1]/CLK} {ALU_R/R_accu_reg[0]/CLK} ALU_R/R_was_1_reg/CLK {ALU_L/y_reg[39]/CLK} {ALU_L/y_reg[38]/CLK} {ALU_L/y_reg[37]/CLK} {ALU_L/y_reg[36]/CLK} {ALU_L/y_reg[35]/CLK} {ALU_L/y_reg[34]/CLK} {ALU_L/y_reg[33]/CLK} {ALU_L/y_reg[32]/CLK} {ALU_L/y_reg[31]/CLK} {ALU_L/y_reg[30]/CLK} {ALU_L/y_reg[29]/CLK} {ALU_L/y_reg[28]/CLK} {ALU_L/y_reg[27]/CLK} {ALU_L/y_reg[26]/CLK} {ALU_L/y_reg[25]/CLK} {ALU_L/y_reg[24]/CLK} {ALU_L/y_reg[23]/CLK} {ALU_L/y_reg[22]/CLK} {ALU_L/y_reg[21]/CLK} {ALU_L/y_reg[20]/CLK} {ALU_L/y_reg[19]/CLK} {ALU_L/y_reg[18]/CLK} {ALU_L/y_reg[17]/CLK} {ALU_L/y_reg[16]/CLK} {ALU_L/y_reg[15]/CLK} {ALU_L/y_reg[14]/CLK} {ALU_L/y_reg[13]/CLK} {ALU_L/y_reg[12]/CLK} {ALU_L/y_reg[11]/CLK} {ALU_L/y_reg[10]/CLK} {ALU_L/y_reg[9]/CLK} {ALU_L/y_reg[8]/CLK} {ALU_L/y_reg[7]/CLK} {ALU_L/y_reg[6]/CLK} {ALU_L/y_reg[5]/CLK} {ALU_L/y_reg[4]/CLK} {ALU_L/y_reg[3]/CLK} {ALU_L/y_reg[2]/CLK} {ALU_L/y_reg[1]/CLK} {ALU_L/y_reg[0]/CLK} {ALU_L/state_reg[1]/CLK} {ALU_L/state_reg[0]/CLK} ALU_L/sign_delay_reg/CLK {ALU_L/j_reg[4]/CLK} {ALU_L/j_reg[3]/CLK} {ALU_L/j_reg[2]/CLK} {ALU_L/j_reg[1]/CLK} {ALU_L/j_reg[0]/CLK} {ALU_L/ite_reg[9]/CLK} {ALU_L/ite_reg[8]/CLK} {ALU_L/ite_reg[7]/CLK} {ALU_L/ite_reg[6]/CLK} {ALU_L/ite_reg[5]/CLK} {ALU_L/ite_reg[4]/CLK} {ALU_L/ite_reg[3]/CLK} {ALU_L/ite_reg[2]/CLK} {ALU_L/ite_reg[1]/CLK} {ALU_L/ite_reg[0]/CLK} {ALU_L/ite_delay_reg[3][8]/CLK} {ALU_L/ite_delay_reg[3][7]/CLK} {ALU_L/ite_delay_reg[3][6]/CLK} {ALU_L/ite_delay_reg[3][5]/CLK} {ALU_L/ite_delay_reg[3][4]/CLK} {ALU_L/ite_delay_reg[3][3]/CLK} {ALU_L/ite_delay_reg[3][2]/CLK} {ALU_L/ite_delay_reg[3][1]/CLK} {ALU_L/ite_delay_reg[3][0]/CLK} {ALU_L/ite_delay_reg[2][8]/CLK} {ALU_L/ite_delay_reg[2][7]/CLK} {ALU_L/ite_delay_reg[2][6]/CLK} {ALU_L/ite_delay_reg[2][5]/CLK} {ALU_L/ite_delay_reg[2][4]/CLK} {ALU_L/ite_delay_reg[2][3]/CLK} {ALU_L/ite_delay_reg[2][2]/CLK} {ALU_L/ite_delay_reg[2][1]/CLK} {ALU_L/ite_delay_reg[2][0]/CLK} {ALU_L/ite_delay_reg[1][8]/CLK} {ALU_L/ite_delay_reg[1][7]/CLK} {ALU_L/ite_delay_reg[1][6]/CLK} {ALU_L/ite_delay_reg[1][5]/CLK} {ALU_L/ite_delay_reg[1][4]/CLK} {ALU_L/ite_delay_reg[1][3]/CLK} {ALU_L/ite_delay_reg[1][2]/CLK} {ALU_L/ite_delay_reg[1][1]/CLK} {ALU_L/ite_delay_reg[1][0]/CLK} {ALU_L/R_accu_reg[8]/CLK} {ALU_L/R_accu_reg[7]/CLK} {ALU_L/R_accu_reg[6]/CLK} {ALU_L/R_accu_reg[5]/CLK} {ALU_L/R_accu_reg[4]/CLK} {ALU_L/R_accu_reg[3]/CLK} {ALU_L/R_accu_reg[2]/CLK} {ALU_L/R_accu_reg[1]/CLK} {ALU_L/R_accu_reg[0]/CLK} ALU_L/R_was_1_reg/CLK} -rank 0 -sources {{Sclk rise}}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group: 3
create_ccopt_skew_group -name 3 -generated  -fragment  -target_insertion_delay 25.8 -target_skew 17.8 -sinks {{s2p/cnt_reg[0]/CLK} s2p/state_reg/CLK {s2p/cnt_reg[1]/CLK} {s2p/cnt_reg[2]/CLK} {s2p/cnt_reg[3]/CLK} {s2p/data_L_reg[15]/CLK} {s2p/data_R_reg[15]/CLK} {s2p/data_R_reg[14]/CLK} {s2p/data_L_reg[14]/CLK} {s2p/data_R_reg[13]/CLK} {s2p/data_L_reg[13]/CLK} {s2p/data_R_reg[12]/CLK} {s2p/data_L_reg[12]/CLK} {s2p/data_R_reg[11]/CLK} {s2p/data_L_reg[11]/CLK} {s2p/data_L_reg[10]/CLK} {s2p/data_R_reg[10]/CLK} {s2p/data_L_reg[9]/CLK} {s2p/data_R_reg[9]/CLK} {s2p/data_L_reg[8]/CLK} {s2p/data_R_reg[8]/CLK} {s2p/data_L_reg[7]/CLK} {s2p/data_R_reg[7]/CLK} {s2p/data_L_reg[6]/CLK} {s2p/data_R_reg[6]/CLK} {s2p/data_L_reg[5]/CLK} {s2p/data_R_reg[5]/CLK} {s2p/data_R_reg[4]/CLK} {s2p/data_L_reg[4]/CLK} {s2p/data_R_reg[3]/CLK} {s2p/data_L_reg[3]/CLK} {s2p/data_L_reg[2]/CLK} {s2p/data_R_reg[2]/CLK} {s2p/data_R_reg[1]/CLK} {s2p/data_L_reg[1]/CLK} {s2p/data_R_reg[0]/CLK} {s2p/data_L_reg[0]/CLK}} -rank 0 -sources {{Dclk rise}}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: icts
switch_ccopt_skew_group_mode -create icts
# Skew Group: Dclk/my_constraint_mode
create_ccopt_skew_group -name Dclk/my_constraint_mode -auto_sinks -sources {Dclk}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group: Sclk/my_constraint_mode
create_ccopt_skew_group -name Sclk/my_constraint_mode -auto_sinks -sources {Sclk}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: stagedepth
switch_ccopt_skew_group_mode -create stagedepth
# Skew Group: stagedepth
create_ccopt_skew_group -name stagedepth -generated  -auto_sinks -sources {{Dclk rise} {Sclk rise}}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group

# Switch back to default mode.
switch_ccopt_skew_group_mode default