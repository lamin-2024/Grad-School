  double _ddfacsdV_nv = 0.0;
  double _ddfsdV_nv = 0.0;
  double _dfsdV_nv = 0.0;
  double _ddiff0sdV_nv = 0.0;
  double _derr_fsdV_nv = 0.0;
  double _dfp_initdV_diff = 0.0;
